//AWS Config
/*AWS.config.region = 'us-east-1'; // Region
AWS.config.credentials = new AWS.CognitoIdentityCredentials({
    IdentityPoolId: 'us-east-1:f45a9b5b-db90-4d73-ba7a-4468ea2b5ceb',
});*/


/*AWS.config.region = 'eu-west-1'; // Region
AWS.config.credentials = new AWS.CognitoIdentityCredentials({
    IdentityPoolId: 'eu-west-1:ee1821e7-dd4a-4ada-97e0-ebab166c13aa',
});*/

AWS.config.region = 'eu-west-1'; // Region
AWS.config.credentials = new AWS.CognitoIdentityCredentials({
    IdentityPoolId: 'eu-west-1:241e13b6-1bfd-4dd2-b420-e38b52cacf7a',
});

var lexruntime = new AWS.LexRuntime();
var lexUserId = 'chatbot-demo' + Date.now();
var sessionAttributes = {};

AWS.config.update({
    region: "eu-west-1",
    accessKeyId: "AKIAI4TL4KNXNBXWNJGQ",
    secretAccessKey: "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"
});

var num_flag = 0;

var url = new URL(location.href);
var url_param = new URLSearchParams(url.search);
var mobile_number = url_param.get('user_id');
var login_msg;

if(mobile_number == '608441166') {
    login_msg = "hi";
    num_flag = 1;
} else if(mobile_number == '608441177') {
    login_msg = "lowbalance intent";
    num_flag = 1;
} else if(mobile_number == '608441188') {
    login_msg = "greet intent personal offer";
    num_flag = 1;
} else if(mobile_number == '608441189') {
    login_msg = "greet intent positive sentiments";
    num_flag = 1;
} else if(mobile_number == '608441190') {
    login_msg = "greet intent negative sentiments";
    num_flag = 1;
}

if(num_flag){
    var param = {
        botAlias: '$LATEST',
        botName: 'Dealer_Droog',
        inputText: login_msg,
        userId: lexUserId,
        sessionAttributes: sessionAttributes
    };
    
    updateDynamo(mobile_number);
    postLex(param);
    
    num_flag = 0;
} else {
    mobile_number = "icon";
}

//udpateDynamo(mobile_number);

function updateDynamo(mobile){
    var table = "current_user_session";
    var key_id = 1;
    
    var params = {
        TableName: table,
        Key: {"ID":key_id},
        UpdateExpression: "SET userId = :u",
        ExpressionAttributeValues:{
            ":u":mobile,
        },
        ReturnValues:"UPDATED_NEW"
    };
    
    var docClient = new AWS.DynamoDB.DocumentClient();

    docClient.update(params, function(err, data) {
        if (err) {
            console.log("Update Error");
            console.log(JSON.stringify(err, undefined, 2));
        } else {
            console.log("Update Success");
            console.log(JSON.stringify(data, undefined, 2));
        }
    });
}

function pushChat() {
    var wisdomText = document.getElementById('wisdom');
    if (wisdomText && wisdomText.value && wisdomText.value.trim().length > 0) {
        var wisdom = wisdomText.value.trim();
        wisdomText.value = '...';
        wisdomText.locked = true;

        // send it to the Lex runtime
        var params = {
            botAlias: '$LATEST',
            botName: 'Dealer_Droog',
            inputText: wisdom,
            userId: lexUserId,
            sessionAttributes: sessionAttributes
        };
                    
        messageDisplay(wisdom,"user");
        
        postLex(params);
        wisdomText.value = '';
        wisdomText.locked = false;
    }
    // we always cancel form submission
    return false;
}

function postLex(params){
    lexruntime.postText(params, function(err, data) {
        if (err) {
            console.log(err, err.stack);
            showError('Error:  ' + err.message + ' (see console for details)');
        }
        if (data) {
            sessionAttributes = data.sessionAttributes;
            //console.log(data.message);
            messageDisplay(data,"lex");
        }
    });
}

function response_click(btn) {
    //messageDisplay(btn.value, "user");
                
    var params = {
        botAlias: '$LATEST',
        botName: 'Dealer_Droog',
        inputText: btn.value,
        userId: lexUserId,
        sessionAttributes: sessionAttributes
    };
    
    postLex(params);
}

function messageDisplay(message,sender) {
    if(sender == 'user') {
        $('<li class="sent"><img src="images/'+mobile_number+'.jpeg" alt="" /><p>' + message + '</p></li>').appendTo($('.messages ul'));
        $('.message-input input').val(null);
    } else {
        console.log(JSON.stringify(message));
        //console.log(message.message.startsWith('{'));
        //console.log(message.hasOwnProperty('responseCard'));
        
        var new_msg = '<li class="replies_q"><img class="profile_icon" src="images/droog_icon.png" alt="" />'
        
        var i;
        if(message.message.startsWith('{')){
            var msg_parse = JSON.parse(message.message);
            var res_count = Object.keys(msg_parse.messages).length;
            for(i = 0; i< res_count;i++){
                $(new_msg + '<p>' + msg_parse.messages[i].value + '</p></li>').appendTo($('.messages ul'));
            }
        } else {
            $(new_msg + '<p>' + message.message + '</p></li>').appendTo($('.messages ul'));
        }
        
        if(message.hasOwnProperty('responseCard')){
            var card = message.responseCard.genericAttachments[0];
            //console.log(Object.keys(card.buttons).length);
            
            var btn_cnt = Object.keys(card.buttons).length;
            
            new_msg = new_msg + '<div class="test">';
            
            //console.log(card.title);
            
            if(card.title != "" && card.title != null){
                new_msg = new_msg + '<span style="margin-bottom: 5px; display: inline-block;">'+card.title+'</span>';
            }
            
            //new_msg = new_msg + '<div class="row">';
            
            var i;
            for(i=0; i<btn_cnt; i++){
                new_msg = new_msg + '<div class="row"> <div class="col-md-12"> <button style="margin-bottom:2px; color:#000000; padding-left:5px; padding-right:5px;" onclick="response_click(this)" value="'+ card.buttons[i].value +'" class="btn btn-block btn-warning">'+ card.buttons[i].text +'</button></div></div>';
            }
            
            new_msg = new_msg + '</div>';
            
            $(new_msg).appendTo($(".messages ul"));
        }
        
        //msg = 
    }
    $(".messages").animate({ scrollTop: $(document).height() }, "fast");
}