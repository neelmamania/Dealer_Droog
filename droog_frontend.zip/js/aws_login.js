/*
AWS.config.region = 'us-east-1'; // Region
AWS.config.credentials = new AWS.CognitoIdentityCredentials({
    IdentityPoolId: 'us-east-1:f45a9b5b-db90-4d73-ba7a-4468ea2b5ceb',
});

var poolData = {
        UserPoolId : 'us-east-1_4R9LeeHUU', // your user pool id here
        ClientId : 'b3apg73r2cfs7eje2grl9d40c' // your app client id here
    };
var userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);
    
var userData = {
    Username : 'neel', // your username here
    Pool : userPool
};
*/

//var userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);

/*AWSCognito.config.region = 'us-east-1';
AWSCognito.config.credentials = new AWS.CognitoIdentityCredentials({
    IdentityPoolId: 'us-east-1:f45a9b5b-db90-4d73-ba7a-4468ea2b5ceb'
});*/

/*function sign_up2(){
    var poolData = {
        UserPoolId : 'us-east-1_4R9LeeHUU', // your user pool id here
        ClientId : 'b3apg73r2cfs7eje2grl9d40c' // your app client id here
    };
    var userPool = new AmazonCognitoIdentity.CognitoUserPool(poolData);
    
    var userData = {
        Username : 'ruju2', // your username here
        Pool : userPool
    };
    alert('hello');
    var attributeList = [];
 
    var dataEmail = {
        Name : 'email',
        Value : 'shah.neel@tcs.com' // your email here
    };
    var dataPhoneNumber = {
        Name : 'phone_number',
        Value : '+27608441169' // your phone number here with +country code and no delimiters in front
    };
    var attributeEmail = new AmazonCognitoIdentity.CognitoUserAttribute(dataEmail);
    var attributePhoneNumber = new AmazonCognitoIdentity.CognitoUserAttribute(dataPhoneNumber);
 
    attributeList.push(attributeEmail);
    attributeList.push(attributePhoneNumber);
 
    var cognitoUser;
    userPool.signUp("ruju2", "qwer123", attributeList, null, function(err, result){
        if (err) {
            console.log("error")
            console.log(JSON.stringify(err));
            return;
        }
        cognitoUser = result.user;
        alert(cognitoUser.getUsername());
        console.log('user name is ' + cognitoUser.getUsername());
    });
    
    cognitoUser.confirmRegistration('123456', true,function(err, result) {
        if (err) {
            alert("error2");
            alert(JSON.stringify(err));
            return;
        }
        console.log('call result: ' + result);
    });
    
    alert('done');
    //window.location = 'chat.html';
    return false;
}*/

/*function login2(){
    var authenticationData = {
        Username : 'neel', // your username here
        Password : 'qwer123', // your password here
    };
    var authenticationDetails = new AmazonCognitoIdentity.AuthenticationDetails(authenticationData);
    
    console.log(JSON.stringify(authenticationDetails));
    console.log(JSON.stringify(userData));
 
    var cognitoUser = new AmazonCognitoIdentity.CognitoUser(userData);
    console.log(JSON.stringify(cognitoUser));
    cognitoUser.authenticateUser(authenticationDetails, {
        onSuccess: function (result) {
            console.log("success");
            var accessToken = result.getAccessToken().getJwtToken();
        },
        
        onFailure: function(err) {
            console.log(err);
            console.log(JSON.stringify(err));
        },
        mfaRequired: function(codeDeliveryDetails) {
            var verificationCode = prompt('Please input verification code' ,'');
            cognitoUser.sendMFACode(verificationCode, this);
        }
    });
    return false;
}*/

AWS.config.update({
    region: "eu-west-1",
    accessKeyId: "AKIAIPYOYVKYRATHOXSA",
    secretAccessKey: "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"
});

/*var docClient = new AWS.DynamoDB.DocumentClient();*/

function loginDynamoUpdate() {
    var table = "current_user_session";
    var key_id = 1;
    var mobile_number = document.getElementById("user_id").value;
    var login_flag=0;
    
    var params = {
        TableName: table,
        Key: {"ID":key_id},
        UpdateExpression: "SET userId = :u",
        ExpressionAttributeValues:{
            ":u":mobile_number,
        },
        ReturnValues:"UPDATED_NEW"
    };
    
    var docClient = new AWS.DynamoDB.DocumentClient();

    docClient.update(params, function(err, data) {
        if (err) {
            console.log("Update Error");
            console.log(JSON.stringify(err, undefined, 2));
            login_flag = 0;
        } else {
            console.log("Update Success");
            console.log(JSON.stringify(data, undefined, 2));
            login_flag = 1;
        }
    });
    alert("hi"+login_flag);
    
    setTimeout(function(){
        alert(login_flag);
    },2000);
}