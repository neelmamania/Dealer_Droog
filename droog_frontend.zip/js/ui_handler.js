function openNav() {
    document.getElementById("mySidenav").style.width = "100%";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}

document.getElementById("wisdom").focus();

var mic_flag = 0;

navigator.mediaDevices.getUserMedia({audio:true}).then(function onSuccess(stream){
    var recorder = window.recorder = new MediaRecorder(stream);
    
    var data = [];
    recorder.ondataavailable = function(e) {
        data.push(e.data);
    };

    recorder.onerror = function(e) {
        throw e.error || new Error(e.name);
    }

    recorder.onstart = function(e) {
        data = [];
    }

    recorder.onstop = function(e) {
        //alert(JSON.stringify(data));
        var blobData = new Blob(data, {type: 'audio/x-l16'});
     
        //audio.src = window.URL.createObjectURL(blobData);

        var reader = new FileReader();
        reader.onload = function() {
            var audioContext = new AudioContext();
            audioContext.decodeAudioData(reader.result, function(buffer) {
                reSample(buffer, 16000, function(newBuffer){
                    var arrayBuffer = convertFloat32ToInt16(newBuffer.getChannelData(0));
                    sendToServer(arrayBuffer);
                });
            });
        };
        reader.readAsArrayBuffer(blobData);
    }
}).catch(function onError(error) {
    console.log(error.message);
});

function reSample(audioBuffer, targetSampleRate, onComplete) {
    var channel = audioBuffer.numberOfChannels;
    var samples = audioBuffer.length * targetSampleRate / audioBuffer.sampleRate;

    var offlineContext = new OfflineAudioContext(channel, samples, targetSampleRate);
    var bufferSource = offlineContext.createBufferSource();
    bufferSource.buffer = audioBuffer;

    bufferSource.connect(offlineContext.destination);
    bufferSource.start(0);
    offlineContext.startRendering().then(function(renderedBuffer){
        onComplete(renderedBuffer);
    })
}

function convertFloat32ToInt16(buffer) {
    var l = buffer.length;
    var buf = new Int16Array(l);
    while (l--) {
        buf[l] = Math.min(1, buffer[l]) * 0x7FFF;
    }
    return buf.buffer;
}

function startDictation() {
    if(!mic_flag){
        window.recorder.start();
        mic_flag = 1;
        //alert("start");
    } else {
        window.recorder.stop();
        mic_flag = 0;
        //alert("stop");
    }
}
            
function sendToServer(audioData){
    //alert("sending to lex");
    var params = {
        botAlias: '$LATEST', /* required */
        botName: 'Dealer_Droog', /* required */
        contentType: 'audio/x-l16; sample-rate=16000; channel-count=1', /* required */
        inputStream: audioData, /* required */
        userId: lexUserId, /* required */
        accept: 'audio/mpeg',
        //sessionAttributes: '' /* This value will be JSON encoded on your behalf with JSON.stringify() */
    };
    lexruntime.postContent(params, function(err, data) {
        if (err){
            console.log('ERROR!', err, err.stack); // an error occurred
        } else {
            var uInt8Array = new Uint8Array(data.audioStream);
            console.log(JSON.stringify(data));
            console.log(data.message);
            messageDisplay(data.inputTranscript,"user");
            var arrayBuffer = uInt8Array.buffer;
            var blob = new Blob([arrayBuffer]);
            var url = URL.createObjectURL(blob);
            audioResponse.src = url;
            audioResponse.play();
            messageDisplay(data, "lex");
        }
    });
}