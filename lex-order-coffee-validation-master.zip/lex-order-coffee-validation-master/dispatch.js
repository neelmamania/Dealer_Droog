'use strict';

const orderCoffee = require('./orderCoffeeBot/orderCoffee');
const balanceCheck = require('./balanceCheck')
const greetlowbalance = require('./lowBalance')
const buyData = require('./buyData')
const buyAirtime = require('./buyAirtimeVodacoin')

module.exports = function(intentRequest) {
  console.log(`dispatch userId=${intentRequest.userId}, intentName=${intentRequest.currentIntent.name}`);
  const intentName = intentRequest.currentIntent.name;

  console.log(intentName + ' was called');
  if (intentName === 'CoffeeOrder') {
    return orderCoffee(intentRequest);
  }
  if (intentName === 'PurchaseData') {
    return buyData(intentRequest);
  }
  if (intentName === 'BalanceCheck') {
	  return balanceCheck(intentRequest);
	}
  if (intentName === 'PurchaseAirtime') {
    return orderCoffee(intentRequest);
  }
  if (intentName === 'greetintentlowbalance') {
    return balanceCheck(intentRequest);
  }
  if(intentName === 'PurchaseAirtimeVodacoins'){
    return buyAirtime(intentRequest);
  }


  throw new Error(`Intent with name ${intentName} not supported`);
};
