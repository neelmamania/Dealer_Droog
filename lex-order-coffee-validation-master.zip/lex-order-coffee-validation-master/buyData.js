'use strict';

const handleFulfillmentCodeHook = require('./dataFulfilment');

module.exports = function(intentRequest) {
  const source = intentRequest.invocationSource;


  if (source === 'FulfillmentCodeHook') {
    console.log("fulfil");
    return handleFulfillmentCodeHook(intentRequest);
  }
};