'use strict';

const lexResponses = require('../lexResponses');
const databaseManager = require('../databaseManager');

function buildFulfilmentResult(fullfilmentState, messageContent) {
  return {
    fullfilmentState,
    message: { contentType: 'PlainText', content: messageContent }
  };
}

function fullfilOrder(amount,item) {
  return databaseManager.saveOrderToDatabase(amount,item).then(item => {
    return buildFulfilmentResult('Fulfilled', `Successfully recahrged ${amount} your airtime balance is ${item.Airtime} `);
  });
}

module.exports = function(intentRequest) {
  var amount = intentRequest.currentIntent.slots.airtime;
  return databaseManager.findActiveUser().then(userId => {
  return databaseManager.findUserFavorite(userId).then(item => {
    return fullfilOrder(amount,item).then(fullfiledOrder => {
      return lexResponses.close(intentRequest.sessionAttributes, fullfiledOrder.fullfilmentState, fullfiledOrder.message);
    });
  })});
  //console.log('amount '+JSON.stringify(data, null, 2));
  //return fullfilOrder(userId,amount,data).then(fullfiledOrder => {
  //  return lexResponses.close(intentRequest.sessionAttributes, fullfiledOrder.fullfilmentState, fullfiledOrder.message);
  //});
};
