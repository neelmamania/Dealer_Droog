'use strict';

const lexResponses = require('../lexResponses');
const databaseManager = require('../databaseManager');
const _ = require('lodash');

const types = ['latte', 'americano', 'cappuccino', 'expresso'];
const sizes = ['double', 'normal', 'large'];

function buildValidationResult(isValid, violatedSlot, messageContent) {
  if (messageContent == null) {
    return {
      isValid,
      violatedSlot,
      
    };
  }
  return {
    isValid,
    violatedSlot,
    message: { contentType: 'PlainText', content: messageContent },
  };
}

function buildUserFavoriteResult(coffee, size, messageContent) {
  return {
    coffee,
    size,
    message: { contentType: 'PlainText', content: messageContent }
  };
}

function getButtons(options) {
  var buttons = [];
  _.forEach(options, option => {
    buttons.push({
      text: option,
      value: option
    });
  });
  return buttons;
}

function getOptions(title, types) {
  return {
    title,
    imageUrl: 'http://www.foodinsight.org/sites/default/files/coffee%20based%20drinks.jpg',
    buttons: getButtons(types)
  };
}
function validateAirtime(airtime){
if(airtime > 1 && airtime < 2001){
	return buildValidationResult(true, null,null);
}
else{
	return buildValidationResult(false, 'airtime', `Invalid amount ${airtime}, Amount should be between 2 and 2000`);
}

}



function findUserFavorite(phoneNumber) {
  return databaseManager.findUserFavorite(phoneNumber).then(item => {
    return buildUserFavoriteResult(item.drink, item.size, `Would you like to order a ${item.size} ${item.drink}?`);
  });
}

module.exports = function(intentRequest) {
  var airtime = intentRequest.currentIntent.slots.airtime;
  var userId = intentRequest.userId;
  const slots = intentRequest.currentIntent.slots;
  console.log("inside dialog");
  if (airtime === null) {
    return Promise.resolve(lexResponses.delegate(intentRequest.sessionAttributes, intentRequest.currentIntent.slots));
} else {
    const validationResult = validateAirtime(airtime);

    if (!validationResult.isValid) {
      slots[`${validationResult.violatedSlot}`] = null;
      return Promise.resolve(
        lexResponses.elicitSlot(
          intentRequest.sessionAttributes,
          intentRequest.currentIntent.name,
          slots,
          validationResult.violatedSlot,
          validationResult.message,
          null,
	  null,
	  null
        )
      );
    }

    //If size is not define then set it as normal
    
    return Promise.resolve(lexResponses.delegate(intentRequest.sessionAttributes, intentRequest.currentIntent.slots));
  }
};
