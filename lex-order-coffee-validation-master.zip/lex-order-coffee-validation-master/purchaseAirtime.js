'use strict';

const handleDialogCodeHook = require('./orderCoffeeBot/manageDialogs');
const handleFulfillmentCodeHook = require('./orderCoffeeBot/manageFullfilment');
const lexResponses = require('./lexResponses');

function buildValidationResult(isValid, violatedSlot, messageContent) {
if (messageContent == null) {
return {
isValid,
violatedSlot
};
}
return {
isValid,
violatedSlot,
message: { contentType: 'PlainText', content: messageContent }
};
}

function validateAmount(amount){
console.log('amount check '+amount);
if(amount < 2 && amount > 2000){
//const options = getOptions('Select Amount between ', ['2', '2000']);
return buildValidationResult(false, 'airtime', `Invalid amount ${amount}, Amount should be between 2 and 2000`);
}
else{
return buildValidationResult(true, null,null);
}
}

module.exports = function(intentRequest, callback) {
var amount = intentRequest.currentIntent.slots.airtime;
console.log('amount '+ amount);
const source = intentRequest.invocationSource;

if (source === 'DialogCodeHook') {
console.log('inside airtime file');
const slots = intentRequest.currentIntent.slots;
if(amount === null){
return lexResponses.delegate(intentRequest.sessionAttributes, intentRequest.currentIntent.slots);
}
//lexResponses.delegate(intentRequest.sessionAttributes, intentRequest.currentIntent.slots);
const validationResult = validateAmount(amount);
console.log('validation result '+validationResult.isValid);
if (validationResult.isValid){
//return callback(lexResponses.confirmIntent(intentRequest.sessionAttributes, intentRequest.currentIntent.name, slots, 'are you sure want to buy ${airtime} airtime ?'));
callback(lexResponses.delegate(intentRequest.sessionAttributes, intentRequest.currentIntent.slots));
return;
}else{
//return callback(lexResponses.elicitSlot(intentRequest.sessionAttributes, intentRequest.currentIntent.name, slots, validationResult.violatedSlot,
// validationResult.message,
// null));
callback(lexResponses.delegate(intentRequest.sessionAttributes, intentRequest.currentIntent.slots));
return;
}
}
}
