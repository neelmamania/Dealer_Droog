'use strict';

const lexResponses = require('./lexResponses');
const databaseManager = require('./databaseManager');
const balanceCheck = require('./balanceCheck');

function buildFulfilmentResult(fullfilmentState, messageContent) {
  return {
    fullfilmentState,
    message: { contentType: 'PlainText', content: messageContent }
  };
}

function fullfilOrder(item,dataSize,recurringOnce,validity) {
  return databaseManager.saveDataToTable(item,dataSize,recurringOnce,validity).then(item => {
    return buildFulfilmentResult('Fulfilled', `Successfully recahrged ${dataSize} ${recurringOnce} expiring on ${validity}`);
  });
}

module.exports = function(intentRequest) {
  var dataSize = intentRequest.currentIntent.slots.DataSize;
  var recurringOnce = intentRequest.currentIntent.slots.Recurring;
  var validity = intentRequest.currentIntent.slots.Validity;
    console.log(recurringOnce);
  return databaseManager.findActiveUser().then(phoneNumber => {
    return databaseManager.findUserFavorite(phoneNumber).then(item => {
        return fullfilOrder(item,dataSize,recurringOnce,validity).then(fullfiledOrder => {
            return lexResponses.close(intentRequest.sessionAttributes, fullfiledOrder.fullfilmentState, fullfiledOrder.message);
    });
  })});
  //console.log('amount '+JSON.stringify(data, null, 2));
  //return fullfilOrder(userId,amount,data).then(fullfiledOrder => {
  //  return lexResponses.close(intentRequest.sessionAttributes, fullfiledOrder.fullfilmentState, fullfiledOrder.message);
  //});
};
