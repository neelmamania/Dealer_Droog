'use strict';

const lexResponses = require('./lexResponses');
const databaseManager = require('./databaseManager');
const AWS = require('aws-sdk');
//var wait = require('wait-for-stuff');
const docClient = new AWS.DynamoDB.DocumentClient();

function buildFulfilmentResult(fullfilmentState, messageContent) {
return {
fullfilmentState,
message: { contentType: 'PlainText', content: messageContent }
};
}
async function retrieveBalance(userId) {

const data = databaseManager.getUserInfo(userId);

console.log('values '+ JSON.stringify(data, null, 2));
//const fulfil = buildFulfilmentResult('Fulfilled', `Your Airtime Balance is ${data.Airtime} , Your Data Balance is ${data.DataBalance} which expires on ${data.DataExpiry} and you have ${data.Vodacoins} vodacoins left.`);
//return databaseManager.getUserInfo(userId).then(data => {
return buildFulfilmentResult('Fulfilled', `Your Airtime Balance is ${data.Airtime} , Your Data Balance is ${data.DataBalance} which expires on ${data.DataExpiry} and you have ${data.Vodacoins} vodacoins left.`);
//}).catch( err => { console.log(err); });
//return fulfil;
}

function fullfilOrder(phoneNumber) {
  return databaseManager.findUserFavorite(phoneNumber).then(item => {
    return buildFulfilmentResult('Fulfilled', `Your Airtime Balance is ${item.Airtime} , Your Data Balance is ${item.DataBalance} which expires on ${item.DataExpiry} and you have ${item.Vodacoins} vodacoins left.`);
  });
}

module.exports = function(intentRequest) {
console.log('in low balance');
const source = intentRequest.invocationSource;
return databaseManager.findActiveUser().then(phoneNumber => {
  return fullfilOrder(phoneNumber).then(fullfiledOrder => {
    return lexResponses.close(intentRequest.sessionAttributes, fullfiledOrder.fullfilmentState, fullfiledOrder.message);
 }) });

};
