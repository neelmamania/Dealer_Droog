'use strict';
const handleDialogCodeHook = require('./airtimeVodacoinDialog');
const handleFulfillmentCodeHook = require('./airtimeVodacoinFulfil');

module.exports = function(intentRequest) {
  const source = intentRequest.invocationSource;
  if (source === 'DialogCodeHook') {
    return handleDialogCodeHook(intentRequest);
  }
  if (source === 'FulfillmentCodeHook') {
    console.log("fulfil");
    return handleFulfillmentCodeHook(intentRequest);
  }
};