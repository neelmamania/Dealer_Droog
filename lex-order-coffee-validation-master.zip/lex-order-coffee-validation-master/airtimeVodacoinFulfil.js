'use strict';

const lexResponses = require('./lexResponses');
const databaseManager = require('./databaseManager');

function buildFulfilmentResult(fullfilmentState, messageContent) {
  return {
    fullfilmentState,
    message: { contentType: 'PlainText', content: messageContent }
  };
}

function fullfilOrder(vodacoins,finalAmount,item) {
  return databaseManager.saveVodacoinAirtime(vodacoins,finalAmount,item).then(item => {
    return buildFulfilmentResult('Fulfilled', `Transaction was successful, We have Credited ${finalAmount} Rands to your account.`);
  });
}

module.exports = function(intentRequest) {
  var vodacoins = intentRequest.currentIntent.slots.vodacoins;
  var finalAmount = intentRequest.currentIntent.slots.tradefinal;
  console.log("vodacoins "+ vodacoins+ ' '+finalAmount);
  return databaseManager.findActiveUser().then(userId => {
  return databaseManager.findUserFavorite(userId).then(item => {
    return fullfilOrder(vodacoins,finalAmount,item).then(fullfiledOrder => {
      return lexResponses.close(intentRequest.sessionAttributes, fullfiledOrder.fullfilmentState, fullfiledOrder.message);
    });
  })});
  //console.log('amount '+JSON.stringify(data, null, 2));
  //return fullfilOrder(userId,amount,data).then(fullfiledOrder => {
  //  return lexResponses.close(intentRequest.sessionAttributes, fullfiledOrder.fullfilmentState, fullfiledOrder.message);
  //});
};
