'use strict';

//const uuidV1 = require('uuid/v1');
const AWS = require('aws-sdk');
const promisify = require('es6-promisify');
const _ = require('lodash');
const dynamo = new AWS.DynamoDB.DocumentClient();

module.exports.saveOrderToDatabase = function(amount, item) {
  console.log('saveOrderToDatabase');
  console.log("${item}");
  return saveItemToTable('User_Current_Plan', amount, item);
};

module.exports.saveDataToTable = function(item,dataSize,recurringOnce,validity) {
  console.log('saveDataToDatabase');
  console.log("user "+recurringOnce + " "+dataSize);
  return saveDataPackToTable('User_Current_Plan', item,dataSize,recurringOnce,validity);
};

module.exports.saveVodacoinAirtime = function(vodacoins,finalAmount,item){
  console.log('vodacoins save '+vodacoins+' '+JSON.stringify(item, null, 2));
  return saveVodacoinAirtimeItem('User_Current_Plan', vodacoins,finalAmount,item);
}

module.exports.findUserFavorite = function(userId) {
  console.log(userId);
  const params = {
    TableName: 'User_Current_Plan',
    Key: {
      PhoneNumber: userId
    }
  };

  const getAsync = promisify(dynamo.get, dynamo);

  return getAsync(params).then(response => {
    if (_.isEmpty(response)) {
      console.log(`User with number :${userId} not found`);
      return Promise.reject(new Error(`User with number :${userId} not found`));
    }
    return response.Item;
  });
};

module.exports.findActiveUser = function() {
  var id = 1;
  const params = {
    TableName: 'current_user_session',
    Key:{
      "ID" : id
    }
  };

  const getAsync = promisify(dynamo.get, dynamo);

  return getAsync(params).then(response => {
    if (_.isEmpty(response)) {
      console.log(`User not found`);
      return Promise.reject(new Error(`User not found`));
    }
    console.log(`active user ${response.Item.userId}`);
    return response.Item.userId;
  });
};

function saveItemToTable(tableName, amount, item) {
  console.log("recharge "+amount);
  console.log('values '+ JSON.stringify(item, null, 2));
  typeof (item.Airtime - 0);
  typeof (amount - 0);
  var cuurent_amount = Number(item.Airtime)+Number(amount);
  typeof (cuurent_amount - 0);
  console.log(`Current Airtime ${Number(cuurent_amount)}`);
  const params = {
    TableName:tableName,
    Key:{
      "PhoneNumber": item.PhoneNumber
    },
    UpdateExpression: "set #t = :amt, DataBalance = :a, ID = :i, DataExpiry = :b, DataPlan = :c, Email = :d, #UserName = :e, PriorityUser = :g, Surname = :h, Vodacoins = :j",
    ExpressionAttributeValues:{
        ":amt": Number(cuurent_amount),
        ":a" : item.DataBalance,
        ":i" : item.ID,
        ":b" : item.DataExpiry,
        ":c" : item.DataPlan,
        ":d" : item.Email,
        ":e" : item.Name,
        ":g" : item.PriorityUser,
        ":h" : item.Surname,
        ":j" : item.Vodacoins
    },
    ExpressionAttributeNames: {
      "#t": "Airtime",
      "#UserName": "Name"
    },
    ReturnValues:"UPDATED_NEW"
  };

  const putAsync = promisify(dynamo.update, dynamo);

  return Promise.resolve(putAsync(params)
    .then(() => {
      console.log(`Saving airtime `+JSON.stringify(item, null, 2));
      const params = {
        TableName: 'User_Current_Plan',
        Key: {
          PhoneNumber: item.PhoneNumber
        }
      };
    
      const getAsync = promisify(dynamo.get, dynamo);
    
      return getAsync(params).then(response => {
        if (_.isEmpty(response)) {
          console.log(`User with number :${userId} not found`);
          return Promise.reject(new Error(`User with number :${userId} not found`));
        }
        return response.Item;
      });
    })
    .catch(error => {
      Promise.reject(error);
    }));

}

function saveVodacoinAirtimeItem(tableName,vodacoins,finalAmount,item){
  console.log("recharge "+Number(finalAmount));
  console.log('values '+ JSON.stringify(item, null, 2));

  var cuurent_amount = Number(item.Airtime)+Number(finalAmount);

  console.log(`Current Airtime ${Number(cuurent_amount)}`);
  const params = {
    TableName:tableName,
    Key:{
      "PhoneNumber": item.PhoneNumber
    },
    UpdateExpression: "set #t = :amt, DataBalance = :a, ID = :i, DataExpiry = :b, DataPlan = :c, Email = :d, #UserName = :e, PriorityUser = :g, Surname = :h, Vodacoins = :j",
    ExpressionAttributeValues:{
        ":amt": Number.parseFloat(cuurent_amount).toPrecision(2),
        ":a" : item.DataBalance,
        ":i" : item.ID,
        ":b" : item.DataExpiry,
        ":c" : item.DataPlan,
        ":d" : item.Email,
        ":e" : item.Name,
        ":g" : item.PriorityUser,
        ":h" : item.Surname,
        ":j" : item.Vodacoins
    },
    ExpressionAttributeNames: {
      "#t": "Airtime",
      "#UserName": "Name"
    },
    ReturnValues:"UPDATED_NEW"
  };

  const putAsync = promisify(dynamo.update, dynamo);

  return Promise.resolve(putAsync(params)
    .then(() => {
      console.log(`Saving airtime `+JSON.stringify(item, null, 2));
      const params = {
        TableName: 'User_Current_Plan',
        Key: {
          PhoneNumber: item.PhoneNumber
        }
      };
    
      const getAsync = promisify(dynamo.get, dynamo);
    
      return getAsync(params).then(response => {
        if (_.isEmpty(response)) {
          console.log(`User with number :${userId} not found`);
          return Promise.reject(new Error(`User with number :${userId} not found`));
        }
        return response.Item;
      });
    })
    .catch(error => {
      Promise.reject(error);
    }));
}



function saveDataPackToTable(tableName, item,dataSize,recurringOnce,validity) {
  console.log("data pack "+dataSize);
  console.log('values '+ JSON.stringify(item, null, 2));
  var total_data = Number(item.DataBalance)+Number(dataSize);
  
  console.log(`Current Airtime ${Number(total_data)}  ${Number(item.DataBalance)}  ${Number(dataSize)} ${recurringOnce}`);
  const params = {
    TableName:tableName,
    Key:{
        "PhoneNumber" : item.PhoneNumber
    },
    UpdateExpression: "set #t = :amt, ID = :i, DataBalance = :a, DataExpiry = :b, #plan = :k, Email = :d, #UserName = :e, PriorityUser = :g, Surname = :h, Vodacoins = :j",
    ExpressionAttributeValues:{
        ":amt": item.Airtime,
        ":i" : item.ID,
        ":a" : Number.parseFloat(total_data).toPrecision(2),
        ":b" : validity,
        ":k" : recurringOnce,
        ":d" : item.Email,
        ":e" : item.Name,        
        ":g" : item.PriorityUser,
        ":h" : item.Surname,
        ":j" : item.Vodacoins
    },
    ExpressionAttributeNames: {
      "#t": "Airtime",
      "#plan": "DataPlan",
      "#UserName": "Name"

    },
    ReturnValues:"UPDATED_NEW"
  };

  const putAsync = promisify(dynamo.update, dynamo);

  return Promise.resolve(putAsync(params)
    .then(() => {
      console.log(`Saving airtime `+JSON.stringify(item, null, 2));
      const params = {
        TableName: 'User_Current_Plan',
        Key: {
          PhoneNumber: item.PhoneNumber
        }
      };
    
      const getAsync = promisify(dynamo.get, dynamo);
    
      return getAsync(params).then(response => {
        if (_.isEmpty(response)) {
          console.log(`User with number :${userId} not found`);
          return Promise.reject(new Error(`User with number :${userId} not found`));
        }
        return response.Item;
      });
      
    })
    .catch(error => {
      Promise.reject(error);
    }));
    

}
