'use strict';

const lexResponses = require('./lexResponses');
const databaseManager = require('./databaseManager');
const _ = require('lodash');

function buildValidationResult(isValid, violatedSlot, messageContent) {
  if (messageContent == null) {
    return {
      isValid,
      violatedSlot,
      
    };
  }
  return {
    isValid,
    violatedSlot,
    message: { contentType: 'PlainText', content: messageContent },
  };
}

function buildUserFavoriteResult(coffee, size, messageContent) {
  return {
    coffee,
    size,
    message: { contentType: 'PlainText', content: messageContent }
  };
}

function validateAirtime(airtime){
if(airtime > 1 && airtime < 2001){
	return buildValidationResult(true, null,null);
}
else{
	return buildValidationResult(false, 'airtime', `Invalid amount ${airtime}, Amount should be between 2 and 2000`);
}

}
function buildMessage(slot,messageContent){
    return {
        slot,
        message: { contentType: 'PlainText', content: messageContent }
    };
}


module.exports = function(intentRequest) {
  var vodacoins = intentRequest.currentIntent.slots.vodacoins;
  var tradeOne = intentRequest.currentIntent.slots.tradeone;
  var tradeTwo = intentRequest.currentIntent.slots.tradetwo;
  var tradeThree = intentRequest.currentIntent.slots.tradethree;
  var tradeFinal = intentRequest.currentIntent.slots.tradefinal;
  var amount;
  console.log("vodacoins " + Number(vodacoins))
  var userId = intentRequest.userId;
  const slots = intentRequest.currentIntent.slots;
  console.log("inside vodacoin dialog " + tradeOne +" "+tradeTwo+" "+tradeThree+" "+tradeFinal);
  
  if (vodacoins === null) {
    return Promise.resolve(lexResponses.delegate(intentRequest.sessionAttributes, intentRequest.currentIntent.slots));
} else {
    if(tradeOne === null && tradeTwo === null && tradeThree === null && tradeFinal === null){
     amount = Number(vodacoins)/20;
    console.log(Number(amount));
    const validMessage = buildMessage('tradeone',`Ok, here's a special deal for you, ${Number.parseFloat(amount).toPrecision(2)} rands Airtime for ${Number(vodacoins)} VodaCoins, What do you say Yes or No?`);
      slots['tradeone'] = null;
      return Promise.resolve(
        lexResponses.elicitSlot(
          intentRequest.sessionAttributes,
          intentRequest.currentIntent.name,
          slots,
          validMessage.slot,
          validMessage.message,
          null,
	      null,
	      null
            )
            );
        
    }
    if(tradeOne === 'No' && tradeTwo === null && tradeThree === null && tradeFinal === null){
         amount = Number(vodacoins)/15;
        console.log(Number(amount));
        const validMessage = buildMessage('tradetwo',`The inside news is, the more Loyal and Regular Customers get, Better deals !! How about ${Number.parseFloat(amount).toPrecision(2)} Rands Airtime for ${Number(vodacoins)} VodaCoins, What do you say Yes or No?`);
        slots['tradetwo'] = null;
        return Promise.resolve(
        lexResponses.elicitSlot(
          intentRequest.sessionAttributes,
          intentRequest.currentIntent.name,
          slots,
          validMessage.slot,
          validMessage.message,
          null,
	      null,
	      null
            )
            );
    
    }if (tradeOne === 'No' && tradeTwo === 'No' && tradeThree === null && tradeFinal === null){
         amount = Number(vodacoins)/12;
        console.log(Number(amount));
        const validMessage = buildMessage('tradethree',`Umm.. No Man, You are streching me way too Thin now !! How about ${Number.parseFloat(amount).toPrecision(2)} Rands Airtime for ${Number(vodacoins)} VodaCoins, What do you say Yes or No?`);
        slots['tradethree'] = null;
        return Promise.resolve(
        lexResponses.elicitSlot(
          intentRequest.sessionAttributes,
          intentRequest.currentIntent.name,
          slots,
          validMessage.slot,
          validMessage.message,
          null,
	      null,
	      null
            )
            );
    }
    /*if(tradeOne === 'No' && tradeTwo === 'No' && tradeThree === 'Yes' && tradeFinal === null) {
        return Promise.resolve(lexResponses.confirmIntent(intentRequest.sessionAttributes, intentRequest.currentIntent.name, slots, `are you sure want to buy ?`));
    }*/
    if(tradeOne === 'No' && tradeTwo === 'No' && tradeThree === 'No' && tradeFinal === null){
        const validMessage = buildMessage('tradethree',`Haven't you received your Salary, Be a Sport man, previous offer is my last, What do you say Yes or No?`);
        slots['tradethree'] = null ;
        return Promise.resolve(
            lexResponses.elicitSlot(
              intentRequest.sessionAttributes,
              intentRequest.currentIntent.name,
              slots,
              validMessage.slot,
              validMessage.message,
              null,
              null,
              null
                )
                );
        //return Promise.resolve(lexResponses.confirmIntent(intentRequest.sessionAttributes, intentRequest.currentIntent.name, slots, `This is our last offer do you want to buy ?`));
    }
	
	if(tradeOne === 'No' && tradeTwo === 'No' && tradeThree === 'No' && tradeFinal === 'No'){
        const validMessage = buildMessage('tradethree',`No Deal! are we done talking?`);
        slots['tradethree'] = null ;
        return Promise.resolve(
            lexResponses.elicitSlot(
              intentRequest.sessionAttributes,
              intentRequest.currentIntent.name,
              slots,
              validMessage.slot,
              validMessage.message,
              null,
              null,
              null
                )
                );
        //return Promise.resolve(lexResponses.confirmIntent(intentRequest.sessionAttributes, intentRequest.currentIntent.name, slots, `This is our last offer do you want to buy ?`));
    }

    
    
        if(tradeOne === 'Yes'){
            slots['tradefinal'] = Number.parseFloat(Number(vodacoins)/20).toPrecision(2) ;

        }
        if(tradeTwo === 'Yes'){
            slots['tradefinal'] = Number.parseFloat(Number(vodacoins)/15).toPrecision(2) ;
        }
        if(tradeThree === 'Yes'){
            slots['tradefinal'] = Number.parseFloat(Number(vodacoins)/12).toPrecision(2) ;
        }

    //If size is not define then set it as normal
    
    //return Promise.resolve(lexResponses.delegate(intentRequest.sessionAttributes, intentRequest.currentIntent.slots));
    return Promise.resolve(lexResponses.delegate(intentRequest.sessionAttributes, intentRequest.currentIntent.slots));
  }
};
